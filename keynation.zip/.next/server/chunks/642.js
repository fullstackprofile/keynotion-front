exports.id = 642;
exports.ids = [642];
exports.modules = {

/***/ 1185:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "x": () => (/* binding */ AnyQuestions)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
/* harmony import */ var _TItle_Title__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8104);
/* harmony import */ var _Input_Input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7391);
/* harmony import */ var _Button_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9246);
/* harmony import */ var _TextArea_TextArea__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3419);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1908);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _AnyQuestions_module_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1144);
/* harmony import */ var _AnyQuestions_module_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_AnyQuestions_module_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _Input_Input__WEBPACK_IMPORTED_MODULE_4__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_7__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _Input_Input__WEBPACK_IMPORTED_MODULE_4__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }













const AnyQuestionsSchema = yup__WEBPACK_IMPORTED_MODULE_8__.object().shape({
  Name: yup__WEBPACK_IMPORTED_MODULE_8__.string().required("please Enter your Name"),
  Email: yup__WEBPACK_IMPORTED_MODULE_8__.string().email().required("please Enter your Email"),
  Number: yup__WEBPACK_IMPORTED_MODULE_8__.number().required("please Enter your Phone Number"),
  Message: yup__WEBPACK_IMPORTED_MODULE_8__.string().required("please Enter your Message")
});
const AnyQuestions = () => {
  const {
    control,
    handleSubmit
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_7__.yupResolver)(AnyQuestionsSchema)
  });
  const onSubmit = handleSubmit(data => {
    console.log(data);
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
    className: (_AnyQuestions_module_css__WEBPACK_IMPORTED_MODULE_10___default().anyQuestions),
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_TItle_Title__WEBPACK_IMPORTED_MODULE_3__/* .Title */ .D, {
      title: "Any?",
      title_2: "Questions",
      nogradiental: true
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
      className: (_AnyQuestions_module_css__WEBPACK_IMPORTED_MODULE_10___default().anyQuestions_content),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
        className: (_AnyQuestions_module_css__WEBPACK_IMPORTED_MODULE_10___default().anyQuestions_form),
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("form", {
          onSubmit: onSubmit,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
            name: "Name",
            control: control,
            render: ({
              field,
              fieldState: {
                error
              }
            }) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
              className: (_AnyQuestions_module_css__WEBPACK_IMPORTED_MODULE_10___default().dialog_content),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_Input_Input__WEBPACK_IMPORTED_MODULE_4__/* .Input */ .I, _objectSpread(_objectSpread({
                type: "text"
              }, field), {}, {
                placeholder: "Name"
              })), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("p", {
                className: (_AnyQuestions_module_css__WEBPACK_IMPORTED_MODULE_10___default().error),
                children: error === null || error === void 0 ? void 0 : error.message
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
            name: "Email",
            control: control,
            render: ({
              field,
              fieldState: {
                error
              }
            }) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
              className: (_AnyQuestions_module_css__WEBPACK_IMPORTED_MODULE_10___default().dialog_content),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_Input_Input__WEBPACK_IMPORTED_MODULE_4__/* .Input */ .I, _objectSpread(_objectSpread({
                type: "text"
              }, field), {}, {
                placeholder: "Email"
              })), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("p", {
                className: (_AnyQuestions_module_css__WEBPACK_IMPORTED_MODULE_10___default().error),
                children: error === null || error === void 0 ? void 0 : error.message
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
            name: "Number",
            control: control,
            render: ({
              field,
              fieldState: {
                error
              }
            }) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
              className: (_AnyQuestions_module_css__WEBPACK_IMPORTED_MODULE_10___default().dialog_content),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_Input_Input__WEBPACK_IMPORTED_MODULE_4__/* .Input */ .I, _objectSpread(_objectSpread({
                type: "text"
              }, field), {}, {
                placeholder: "Number"
              })), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("p", {
                className: (_AnyQuestions_module_css__WEBPACK_IMPORTED_MODULE_10___default().error),
                children: error === null || error === void 0 ? void 0 : error.message
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
            name: "Message",
            control: control,
            render: ({
              field,
              fieldState: {
                error
              }
            }) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
              className: (_AnyQuestions_module_css__WEBPACK_IMPORTED_MODULE_10___default().dialog_content),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_TextArea_TextArea__WEBPACK_IMPORTED_MODULE_6__/* .TextArea */ .K, _objectSpread({
                placeholder: "Message"
              }, field)), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("p", {
                className: (_AnyQuestions_module_css__WEBPACK_IMPORTED_MODULE_10___default().error),
                children: error === null || error === void 0 ? void 0 : error.message
              })]
            })
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
            className: (_AnyQuestions_module_css__WEBPACK_IMPORTED_MODULE_10___default().dialog_content_btn),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
              className: (_AnyQuestions_module_css__WEBPACK_IMPORTED_MODULE_10___default().btn),
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_Button_Button__WEBPACK_IMPORTED_MODULE_5__/* .ButtonComp */ .C, {
                title: "Send",
                type: "submit",
                big: true
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
              className: (_AnyQuestions_module_css__WEBPACK_IMPORTED_MODULE_10___default().dialog_content_info),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                src: "/PhoneIcon.svg",
                alt: "PhoneIcon.svg",
                width: 34,
                height: 34
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("p", {
                className: (_AnyQuestions_module_css__WEBPACK_IMPORTED_MODULE_10___default().dialog_content_info_title),
                children: "+44 203 773 8656"
              })]
            })]
          })]
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
          src: "/AnyQuestion.png",
          alt: "AnyQuestion.png",
          width: 632,
          height: 504
        })
      })]
    })]
  });
};
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1494:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "j": () => (/* binding */ Event)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./components/Button/Button.js
var Button = __webpack_require__(9246);
// EXTERNAL MODULE: ./components/Event/Category/Category.module.css
var Category_module = __webpack_require__(5510);
var Category_module_default = /*#__PURE__*/__webpack_require__.n(Category_module);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/Event/Category/Category.js





const Category = ({
  title,
  active,
  onClick
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (Category_module_default()).btn,
      onClick: onClick,
      children: /*#__PURE__*/jsx_runtime_.jsx(Button/* ButtonComp */.C, {
        title: title,
        transparent: active === title ? false : true
      })
    })
  });
};
// EXTERNAL MODULE: ./components/Event/Event.module.css
var Event_module = __webpack_require__(7237);
var Event_module_default = /*#__PURE__*/__webpack_require__.n(Event_module);
;// CONCATENATED MODULE: ./components/Event/Event.js



 // const items = [
//     {
//         id: 1,
//         title: "All categories",
//         categoryItems: []
//     }
// ]



const categorys = [{
  title: "All Categories"
}, {
  title: "Live"
}, {
  title: "Virtual"
}];
const Event = ({
  All,
  Live,
  Virtual
}) => {
  const [active, setActive] = external_react_default().useState("All Categories");
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (Event_module_default()).event,
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (Event_module_default()).event_category,
      children: categorys.map(({
        title
      }) => /*#__PURE__*/jsx_runtime_.jsx(Category, {
        title: title,
        active: active,
        onClick: () => setActive(title)
      }, title))
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (Event_module_default()).events,
      children: active === "All Categories" ? All.map(({
        title
      }) => /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Event_module_default()).event_body,
        children: title
      }, title)) : active === "Live" ? Live.map(({
        title
      }) => /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Event_module_default()).event_body,
        children: title
      }, title)) : active === "Virtual" && Virtual.map(({
        title
      }) => /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Event_module_default()).event_body,
        children: title
      }, title))
    })]
  });
};

/***/ }),

/***/ 9639:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ EventsHead)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Head_Header_Header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(646);
/* harmony import */ var _EventsHead_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3989);
/* harmony import */ var _EventsHead_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_EventsHead_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Head_Header_Header__WEBPACK_IMPORTED_MODULE_1__]);
_Head_Header_Header__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const EventsHead = () => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
    className: (_EventsHead_module_css__WEBPACK_IMPORTED_MODULE_3___default().eventsHead),
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_Head_Header_Header__WEBPACK_IMPORTED_MODULE_1__/* .Header */ .h, {})
  });
};
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3419:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K": () => (/* binding */ TextArea)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_TextareaAutosize__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8383);
/* harmony import */ var _mui_material_TextareaAutosize__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TextareaAutosize__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _TextArea_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6708);
/* harmony import */ var _TextArea_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_TextArea_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
const _excluded = ["placeholder"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





const TextArea = _ref => {
  let {
    placeholder
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
    className: (_TextArea_module_css__WEBPACK_IMPORTED_MODULE_3___default().textArea_block),
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx((_mui_material_TextareaAutosize__WEBPACK_IMPORTED_MODULE_1___default()), _objectSpread({
      placeholder: placeholder,
      className: (_TextArea_module_css__WEBPACK_IMPORTED_MODULE_3___default().textArea)
    }, rest))
  });
};

/***/ }),

/***/ 1144:
/***/ ((module) => {

// Exports
module.exports = {
	"anyQuestions": "AnyQuestions_anyQuestions__ozKe4",
	"anyQuestions_content": "AnyQuestions_anyQuestions_content__wqFgY",
	"anyQuestions_form": "AnyQuestions_anyQuestions_form__g5er9",
	"dialog_content": "AnyQuestions_dialog_content__YWNXG",
	"dialog_content_btn": "AnyQuestions_dialog_content_btn__D3jlD",
	"dialog_content_info": "AnyQuestions_dialog_content_info__v1ETy",
	"dialog_content_info_title": "AnyQuestions_dialog_content_info_title__hKnwP"
};


/***/ }),

/***/ 5510:
/***/ ((module) => {

// Exports
module.exports = {
	"btn": "Category_btn__5lgkz"
};


/***/ }),

/***/ 7237:
/***/ ((module) => {

// Exports
module.exports = {
	"event": "Event_event__LxIe2",
	"event_category": "Event_event_category___l0ry",
	"events": "Event_events__083D5",
	"event_body": "Event_event_body__nAnDp"
};


/***/ }),

/***/ 3989:
/***/ ((module) => {

// Exports
module.exports = {
	"eventsHead": "EventsHead_eventsHead__fXjfc"
};


/***/ }),

/***/ 6708:
/***/ ((module) => {

// Exports
module.exports = {
	"textArea": "TextArea_textArea__Xae0i",
	"textArea_block": "TextArea_textArea_block__TroTT"
};


/***/ })

};
;