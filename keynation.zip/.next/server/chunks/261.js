exports.id = 261;
exports.ids = [261];
exports.modules = {

/***/ 9246:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* binding */ ButtonComp)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Button_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2804);
/* harmony import */ var _Button_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_Button_module_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);




const ButtonComp = ({
  title,
  transparent,
  big,
  onClick
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
    children: big ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Button, {
      onClick: onClick,
      type: "submit",
      className: transparent ? (_Button_module_css__WEBPACK_IMPORTED_MODULE_2___default().btn_see_more_2) : big ? (_Button_module_css__WEBPACK_IMPORTED_MODULE_2___default().btn_see_more_big) : (_Button_module_css__WEBPACK_IMPORTED_MODULE_2___default().btn_see_more),
      variant: "contained",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("p", {
        className: transparent && (_Button_module_css__WEBPACK_IMPORTED_MODULE_2___default().btn_title),
        children: title
      })
    }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Button, {
      onClick: onClick,
      type: "submit",
      className: transparent ? (_Button_module_css__WEBPACK_IMPORTED_MODULE_2___default().btn_see_more_2) : (_Button_module_css__WEBPACK_IMPORTED_MODULE_2___default().btn_see_more),
      variant: "contained",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("p", {
        className: transparent && (_Button_module_css__WEBPACK_IMPORTED_MODULE_2___default().btn_title),
        children: title
      })
    })
  });
};

/***/ }),

/***/ 4392:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y": () => (/* binding */ SmallButton)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _SmallButton_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8604);
/* harmony import */ var _SmallButton_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_SmallButton_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);





const SmallButton = ({
  title,
  transparent,
  onClick
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
      onClick: onClick,
      className: transparent ? (_SmallButton_module_css__WEBPACK_IMPORTED_MODULE_3___default().btn_see_more_2) : (_SmallButton_module_css__WEBPACK_IMPORTED_MODULE_3___default().btn_see_more),
      variant: "contained",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("p", {
        className: transparent && (_SmallButton_module_css__WEBPACK_IMPORTED_MODULE_3___default().btn_title),
        children: title
      })
    })
  });
};

/***/ }),

/***/ 4539:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ Footer)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Footer_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8253);
/* harmony import */ var _Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_Footer_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Button_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9246);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);





const Footer = () => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
    className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().footer_wrapper),
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().footer),
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
        className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().footer_content),
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
          className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().keyNation),
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
            className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().keyNation_title_block),
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("p", {
              className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().keyNation_title),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("span", {
                className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().gradient),
                children: "KEY-NOTION"
              }), ".COM"]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
            className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().keyNation_subTitle_block),
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("p", {
              className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().keyNation_subTitle),
              children: "A Professional Conference Organizing Company."
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_Button_Button__WEBPACK_IMPORTED_MODULE_1__/* .ButtonComp */ .C, {
              title: "Contact Us"
            })
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
          className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().left_block),
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
            className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().officess),
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
              className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().prague_office),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("p", {
                className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().prague_title),
                children: "Prague Office"
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
                className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().prague_titles),
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("p", {
                  className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().subTitle),
                  children: "Zverinova 3428/5, 130 00 Praha 3 Strasnice"
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("p", {
                  className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().subTitle),
                  children: "Czech Republic"
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("p", {
                  className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().subTitle),
                  children: "Finance@key-notion.com"
                }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("p", {
                  className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().prague_phone),
                  children: ["Phone : ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("span", {
                    className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().strong),
                    children: "+420 228 887 628"
                  })]
                })]
              })]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
              className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().us_office),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("p", {
                className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().prague_title),
                children: "US Office"
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
                className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().prague_titles),
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("p", {
                  className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().subTitle),
                  children: "Finance@key-notion.com"
                }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("p", {
                  className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().prague_phone),
                  children: ["Phone : ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("span", {
                    className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().strong),
                    children: "+1 470 845 1675"
                  })]
                })]
              })]
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
            className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().London_office),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("p", {
              className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().prague_title),
              children: "London Office"
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
              className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().prague_titles),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("p", {
                className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().subTitle),
                children: "3rd Floor, 120 Baker Street, Westminster, London, W1U 6TU\u200B"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("p", {
                className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().subTitle),
                children: "UK"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("p", {
                className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().subTitle),
                children: "Finance@key-notion.com"
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("p", {
                className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().prague_phone),
                children: ["Phone : ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("span", {
                  className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().strong),
                  children: "+44 203 773 8656"
                })]
              })]
            })]
          })]
        })]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().row),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("p", {
        className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_3___default().row_title),
        children: "\xA9 2022 - Copyright | All rights Reserved"
      })
    })]
  });
};

/***/ }),

/***/ 646:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ Header)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Button_SmallButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4392);
/* harmony import */ var _HeaderNavbar_HeaderNavbar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2283);
/* harmony import */ var _Login_Login__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5167);
/* harmony import */ var _SignUp_SignUp__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(694);
/* harmony import */ var _Header_module_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(60);
/* harmony import */ var _Header_module_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_Header_module_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _Login_ForgotPass_ForgotPass__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4710);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Login_Login__WEBPACK_IMPORTED_MODULE_5__, _SignUp_SignUp__WEBPACK_IMPORTED_MODULE_6__, _Login_ForgotPass_ForgotPass__WEBPACK_IMPORTED_MODULE_7__]);
([_Login_Login__WEBPACK_IMPORTED_MODULE_5__, _SignUp_SignUp__WEBPACK_IMPORTED_MODULE_6__, _Login_ForgotPass_ForgotPass__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const Header = () => {
  const [openLogin, setOpenLogin] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(false);
  const [openSingup, setOpenSingup] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(false);
  const [openForgot, setOpenForgot] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(false);

  const handleClickOpenSignup = () => {
    setOpenSingup(true);
  };

  const handleClickCloseSignup = () => {
    setOpenSingup(false);
  };

  const handleClickOpen = () => {
    setOpenLogin(true);
  };

  const handleClose = () => {
    setOpenLogin(false);
  };

  const handleClickOpenForgot = () => {
    setOpenLogin(false);
    setOpenForgot(true);
  };

  const handleCloseForgot = () => {
    setOpenForgot(false);
    setOpenLogin(true);
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
    className: (_Header_module_css__WEBPACK_IMPORTED_MODULE_9___default().header),
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
      href: "/",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
        className: (_Header_module_css__WEBPACK_IMPORTED_MODULE_9___default().header_logo),
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
          src: "/HeaderLogo.png",
          alt: "Logo",
          width: 91,
          height: 64
        })
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
      className: (_Header_module_css__WEBPACK_IMPORTED_MODULE_9___default().header_nav_login),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_HeaderNavbar_HeaderNavbar__WEBPACK_IMPORTED_MODULE_4__/* .HeaderNavbar */ .N, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
        className: (_Header_module_css__WEBPACK_IMPORTED_MODULE_9___default().shopingCart),
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
          src: "/shopingCart.svg",
          alt: "shopCart",
          width: 31,
          height: 38
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
        className: (_Header_module_css__WEBPACK_IMPORTED_MODULE_9___default().header_login_reg),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Button_SmallButton__WEBPACK_IMPORTED_MODULE_3__/* .SmallButton */ .Y, {
            title: "Log In",
            onClick: handleClickOpen,
            transparent: true
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Button_SmallButton__WEBPACK_IMPORTED_MODULE_3__/* .SmallButton */ .Y, {
            title: "Sign Up",
            onClick: handleClickOpenSignup
          })
        })]
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Login_Login__WEBPACK_IMPORTED_MODULE_5__/* .Login */ .m, {
      open: openLogin,
      handleClose: handleClose,
      handleClickOpenForgot: handleClickOpenForgot
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_SignUp_SignUp__WEBPACK_IMPORTED_MODULE_6__/* .SignUp */ .M, {
      open: openSingup,
      handleClose: handleClickCloseSignup
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Login_ForgotPass_ForgotPass__WEBPACK_IMPORTED_MODULE_7__/* .ForgotPass */ .n, {
      open: openForgot,
      handleClose: handleCloseForgot
    })]
  });
};
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2283:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "N": () => (/* binding */ HeaderNavbar)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "@mui/material/ClickAwayListener"
var ClickAwayListener_ = __webpack_require__(5371);
var ClickAwayListener_default = /*#__PURE__*/__webpack_require__.n(ClickAwayListener_);
// EXTERNAL MODULE: ./components/Head/Header/HeaderNavbar/dropdownMenu/DropdownMenu.module.css
var DropdownMenu_module = __webpack_require__(398);
var DropdownMenu_module_default = /*#__PURE__*/__webpack_require__.n(DropdownMenu_module);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/Head/Header/HeaderNavbar/dropdownMenu/DropdownMenu.js








const DropdownMenu = ({
  title,
  modal,
  href
}) => {
  const [open, setOpen] = external_react_default().useState(false);

  const handleOpen = () => {
    setOpen(!open);
  };

  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx((ClickAwayListener_default()), {
      onClickAway: () => setOpen(false),
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (DropdownMenu_module_default()).dropdown,
        onClick: handleOpen,
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (DropdownMenu_module_default()).dropdown_,
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (DropdownMenu_module_default()).dropdown_head,
            children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
              className: (DropdownMenu_module_default()).menu_item,
              children: title
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: (DropdownMenu_module_default()).dropdown_icon_block,
              children: /*#__PURE__*/jsx_runtime_.jsx((image_default()), {
                src: "/arrowbottom.svg",
                alt: "arrow",
                width: 12,
                height: 12
              })
            })]
          }), open && /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (DropdownMenu_module_default()).dropedMenu,
            children: modal.map(({
              modalTitle,
              href
            }) => /*#__PURE__*/jsx_runtime_.jsx((link_default()), {
              href: href ? `/${href}` : "#",
              children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: (DropdownMenu_module_default()).dropedMenu_item,
                children: /*#__PURE__*/jsx_runtime_.jsx("p", {
                  className: (DropdownMenu_module_default()).dropedMenu_item_title,
                  children: modalTitle
                })
              })
            }))
          })]
        })
      })
    })
  });
};
// EXTERNAL MODULE: ./components/Head/Header/HeaderNavbar/HeaderNavbar.module.css
var HeaderNavbar_module = __webpack_require__(3787);
var HeaderNavbar_module_default = /*#__PURE__*/__webpack_require__.n(HeaderNavbar_module);
;// CONCATENATED MODULE: ./components/Head/Header/HeaderNavbar/HeaderNavbar.js






const HeaderNavbarItems = [{
  title: "Home"
}, {
  title: "Events",
  modal: [{
    modalTitle: "Upcoming Events",
    href: "Events"
  }, {
    modalTitle: "Past Events",
    href: "PastEvents"
  }, {
    modalTitle: "Sponsorship",
    href: "Sponsorship"
  }]
}, {
  title: "Company",
  modal: [{
    modalTitle: "About Us"
  }, {
    modalTitle: "Careers"
  }, {
    modalTitle: "Contact Us"
  }, {
    modalTitle: "Data Privacy"
  }]
}, {
  title: "Gallery"
}, {
  title: "Blog",
  modal: [{
    modalTitle: "Home"
  }, {
    modalTitle: "Latest News"
  }, {
    modalTitle: "Technology"
  }, {
    modalTitle: "Buisness"
  }, {
    modalTitle: "Finance"
  }, {
    modalTitle: "Healthcare"
  }, {
    modalTitle: "Retail"
  }, {
    modalTitle: "Consumer Goods"
  }]
}];
const HeaderNavbar = () => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: (HeaderNavbar_module_default()).HeaderNavbar,
    children: /*#__PURE__*/jsx_runtime_.jsx("ul", {
      className: (HeaderNavbar_module_default()).nav_items,
      children: HeaderNavbarItems.map(({
        title,
        modal
      }) => /*#__PURE__*/jsx_runtime_.jsx("li", {
        className: (HeaderNavbar_module_default()).nav_item,
        children: modal ? /*#__PURE__*/jsx_runtime_.jsx(DropdownMenu, {
          title: title,
          modal: modal
        }) : /*#__PURE__*/jsx_runtime_.jsx((link_default()), {
          href: title,
          children: /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: (HeaderNavbar_module_default()).menu_item,
            children: title
          })
        })
      }, title))
    })
  });
};

/***/ }),

/***/ 7391:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ Input)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Input_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6015);
/* harmony import */ var _Input_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_Input_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
const _excluded = ["type", "placeholder", "showPass", "single", "name"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }








const Input = _ref => {
  let {
    type,
    placeholder,
    showPass,
    single,
    name
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  const [show, setShow] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(false);

  if (showPass) {
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
      className: classnames__WEBPACK_IMPORTED_MODULE_3___default()((_Input_module_css__WEBPACK_IMPORTED_MODULE_5___default().input_block), (_Input_module_css__WEBPACK_IMPORTED_MODULE_5___default().input_block_2), (_Input_module_css__WEBPACK_IMPORTED_MODULE_5___default().input_pass)),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("input", _objectSpread(_objectSpread({}, rest), {}, {
        type: show ? "text" : "password",
        placeholder: placeholder,
        className: (_Input_module_css__WEBPACK_IMPORTED_MODULE_5___default().input),
        name: name
      })), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("span", {
        className: (_Input_module_css__WEBPACK_IMPORTED_MODULE_5___default().showPass_icon),
        onClick: () => setShow(!show),
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
          src: show ? "/passwordShow.svg" : "/passwordUnShow.svg",
          alt: "icon",
          width: 30,
          height: 29
        })
      })]
    });
  }

  if (single) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
      className: (_Input_module_css__WEBPACK_IMPORTED_MODULE_5___default().input_block),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("input", _objectSpread(_objectSpread({}, rest), {}, {
        type: type,
        placeholder: placeholder,
        className: (_Input_module_css__WEBPACK_IMPORTED_MODULE_5___default().input),
        name: name
      }))
    });
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()((_Input_module_css__WEBPACK_IMPORTED_MODULE_5___default().input_block), (_Input_module_css__WEBPACK_IMPORTED_MODULE_5___default().input_block_2)),
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("input", _objectSpread(_objectSpread({}, rest), {}, {
      type: type,
      placeholder: placeholder,
      className: (_Input_module_css__WEBPACK_IMPORTED_MODULE_5___default().input),
      name: name
    }))
  });
};
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4710:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "n": () => (/* binding */ ForgotPass)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
/* harmony import */ var _Button_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9246);
/* harmony import */ var _Input_Input__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7391);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1908);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _ForgotPass_module_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6107);
/* harmony import */ var _ForgotPass_module_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_ForgotPass_module_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _Input_Input__WEBPACK_IMPORTED_MODULE_5__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_6__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _Input_Input__WEBPACK_IMPORTED_MODULE_5__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }













const ForgotPass = ({
  open,
  handleClose
}) => {
  const ForgotPassSchema = yup__WEBPACK_IMPORTED_MODULE_7__.object().shape({
    Email: yup__WEBPACK_IMPORTED_MODULE_7__.string().email().required("please Enter your Email")
  });
  const {
    control,
    handleSubmit
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_6__.yupResolver)(ForgotPassSchema)
  });

  const onSubmit = data => {
    console.log(data);
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Dialog, {
      open: open,
      onClose: handleClose,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
        className: (_ForgotPass_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_head),
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
          className: (_ForgotPass_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_back),
          onClick: handleClose,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
            src: "/arrowBack.svg",
            width: 22,
            height: 22
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
            className: (_ForgotPass_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_back_title),
            children: "Back"
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
          className: (_ForgotPass_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_close),
          onClick: handleClose,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
            src: "/closeIcon.png",
            width: 36,
            height: 36
          })
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
        className: (_ForgotPass_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_head_subTitle_block),
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("p", {
          className: (_ForgotPass_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_head_subTitle),
          children: ["Lost your password? Please enter your username or email address.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("br", {}), "You will receive a link to create a new password via email."]
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("form", {
        onSubmit: handleSubmit(onSubmit),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.Controller, {
          name: "Email",
          control: control,
          render: ({
            field,
            fieldState: {
              error
            }
          }) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
            className: (_ForgotPass_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_content),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
              className: (_ForgotPass_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_label),
              children: "Username or Email Address"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Input_Input__WEBPACK_IMPORTED_MODULE_5__/* .Input */ .I, _objectSpread({
              type: "text"
            }, field)), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
              className: (_ForgotPass_module_css__WEBPACK_IMPORTED_MODULE_9___default().error),
              children: error === null || error === void 0 ? void 0 : error.message
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
          className: (_ForgotPass_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_content_btn),
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
            className: (_ForgotPass_module_css__WEBPACK_IMPORTED_MODULE_9___default().btn),
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Button_Button__WEBPACK_IMPORTED_MODULE_4__/* .ButtonComp */ .C, {
              title: "Reset Password",
              big: true
            })
          })
        })]
      })]
    })
  });
};
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5167:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ Login)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Input_Input__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7391);
/* harmony import */ var _Button_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9246);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1908);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5641);
/* harmony import */ var _Login_module_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(18);
/* harmony import */ var _Login_module_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_Login_module_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Input_Input__WEBPACK_IMPORTED_MODULE_3__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__, react_hook_form__WEBPACK_IMPORTED_MODULE_7__]);
([_Input_Input__WEBPACK_IMPORTED_MODULE_3__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__, react_hook_form__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }













const LoginSchema = yup__WEBPACK_IMPORTED_MODULE_6__.object().shape({
  Email: yup__WEBPACK_IMPORTED_MODULE_6__.string().email().required("please Enter your Email"),
  Password: yup__WEBPACK_IMPORTED_MODULE_6__.string().required("please Enter your Password")
});
const Login = ({
  open,
  handleClose,
  handleClickOpenForgot
}) => {
  const {
    control,
    handleSubmit
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_7__.useForm)({
    defaultValues: {
      Checked: false
    },
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__.yupResolver)(LoginSchema)
  });

  const onSubmit = data => {
    console.log(data);
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Dialog, {
      open: open,
      onClose: handleClose,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
        className: (_Login_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_head),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
          className: (_Login_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_title),
          children: "Log In"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
          className: (_Login_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_close),
          onClick: handleClose,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
            src: "/closeIcon.png",
            width: 36,
            height: 36
          })
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("form", {
        onSubmit: handleSubmit(onSubmit),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_7__.Controller, {
          name: "Email",
          control: control,
          render: ({
            field,
            fieldState: {
              error
            }
          }) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
            className: (_Login_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_content),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
              className: (_Login_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_label),
              children: "Username or Email Address"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Input_Input__WEBPACK_IMPORTED_MODULE_3__/* .Input */ .I, _objectSpread({
              type: "text"
            }, field)), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
              className: (_Login_module_css__WEBPACK_IMPORTED_MODULE_9___default().error),
              children: error === null || error === void 0 ? void 0 : error.message
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_7__.Controller, {
          name: "Password",
          control: control,
          render: ({
            field,
            fieldState: {
              error
            }
          }) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
            className: (_Login_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_content_pass),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
              className: (_Login_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_label),
              children: "Password"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Input_Input__WEBPACK_IMPORTED_MODULE_3__/* .Input */ .I, _objectSpread({
              type: "text",
              showPass: true
            }, field)), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
              className: (_Login_module_css__WEBPACK_IMPORTED_MODULE_9___default().error),
              children: error === null || error === void 0 ? void 0 : error.message
            })]
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_7__.Controller, {
          name: "Checked",
          control: control,
          render: ({
            field
          }) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
            className: (_Login_module_css__WEBPACK_IMPORTED_MODULE_9___default().remember),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Checkbox, _objectSpread({}, field)), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
              className: (_Login_module_css__WEBPACK_IMPORTED_MODULE_9___default().remember_label),
              children: "Remember me"
            })]
          })
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
          className: (_Login_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_content_btn),
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
            className: (_Login_module_css__WEBPACK_IMPORTED_MODULE_9___default().btn),
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Button_Button__WEBPACK_IMPORTED_MODULE_4__/* .ButtonComp */ .C, {
              title: "Log In",
              big: true
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
            className: (_Login_module_css__WEBPACK_IMPORTED_MODULE_9___default().forget),
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
              className: (_Login_module_css__WEBPACK_IMPORTED_MODULE_9___default().forget_title),
              onClick: handleClickOpenForgot,
              children: "Forgot Password?"
            })
          })]
        })]
      })]
    })
  });
};
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 694:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ SignUp)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Button_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9246);
/* harmony import */ var _Input_Input__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7391);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1908);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _SignUp_module_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9240);
/* harmony import */ var _SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _Input_Input__WEBPACK_IMPORTED_MODULE_5__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_6__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _Input_Input__WEBPACK_IMPORTED_MODULE_5__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }













const RegisterSchema = yup__WEBPACK_IMPORTED_MODULE_7__.object().shape({
  firstName: yup__WEBPACK_IMPORTED_MODULE_7__.string().required("please Enter your First Name"),
  lastName: yup__WEBPACK_IMPORTED_MODULE_7__.string().required("please Enter your Last Name"),
  PhoneNumber: yup__WEBPACK_IMPORTED_MODULE_7__.number().required("please Enter your Phone Number"),
  Email: yup__WEBPACK_IMPORTED_MODULE_7__.string().email().required("please Enter your Email"),
  Country: yup__WEBPACK_IMPORTED_MODULE_7__.string().required("please Enter your Country"),
  Password: yup__WEBPACK_IMPORTED_MODULE_7__.string().required("please Enter your Password"),
  Password_2: yup__WEBPACK_IMPORTED_MODULE_7__.string().required('Please retype your password.').oneOf([yup__WEBPACK_IMPORTED_MODULE_7__.ref('Password')], 'Your passwords do not match.')
});
const SignUp = ({
  open,
  handleClose
}) => {
  const {
    control,
    handleSubmit
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_6__.yupResolver)(RegisterSchema)
  });

  const onSubmit = data => {
    console.log(data);
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Dialog, {
      open: open,
      onClose: handleClose,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
        className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_head),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
          className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_title),
          children: "Sign Up"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
          className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_close),
          onClick: handleClose,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
            src: "/closeIcon.png",
            width: 36,
            height: 36
          })
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("form", {
        onSubmit: handleSubmit(onSubmit),
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
          className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_filds),
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
            name: "firstName",
            control: control,
            render: ({
              field,
              fieldState: {
                error
              }
            }) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
              className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_content),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
                className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_label),
                children: "First Name"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Input_Input__WEBPACK_IMPORTED_MODULE_5__/* .Input */ .I, _objectSpread({
                type: "text"
              }, field)), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
                className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().error),
                children: error === null || error === void 0 ? void 0 : error.message
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
            name: "lastName",
            control: control,
            render: ({
              field,
              fieldState: {
                error
              }
            }) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
              className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_content),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
                className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_label),
                children: "Last Name"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Input_Input__WEBPACK_IMPORTED_MODULE_5__/* .Input */ .I, _objectSpread({
                type: "text"
              }, field)), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
                className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().error),
                children: error === null || error === void 0 ? void 0 : error.message
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
            name: "PhoneNumber",
            control: control,
            render: ({
              field,
              fieldState: {
                error
              }
            }) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
              className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_content),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
                className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_label),
                children: "Phone Number"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Input_Input__WEBPACK_IMPORTED_MODULE_5__/* .Input */ .I, _objectSpread({
                type: "text"
              }, field)), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
                className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().error),
                children: error === null || error === void 0 ? void 0 : error.message
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
            name: "Email",
            control: control,
            render: ({
              field,
              fieldState: {
                error
              }
            }) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
              className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_content),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
                className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_label),
                children: "Email"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Input_Input__WEBPACK_IMPORTED_MODULE_5__/* .Input */ .I, _objectSpread({
                type: "text"
              }, field)), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
                className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().error),
                children: error === null || error === void 0 ? void 0 : error.message
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
            name: "Country",
            control: control,
            render: ({
              field,
              fieldState: {
                error
              }
            }) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
              className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_content),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
                className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_label),
                children: "Country"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Input_Input__WEBPACK_IMPORTED_MODULE_5__/* .Input */ .I, _objectSpread({
                type: "text"
              }, field)), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
                className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().error),
                children: error === null || error === void 0 ? void 0 : error.message
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
            name: "Password",
            control: control,
            render: ({
              field,
              fieldState: {
                error
              }
            }) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
              className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_content),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
                className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_label),
                children: "Password"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Input_Input__WEBPACK_IMPORTED_MODULE_5__/* .Input */ .I, _objectSpread({
                type: "text",
                showPass: true
              }, field)), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
                className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().error),
                children: error === null || error === void 0 ? void 0 : error.message
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
            name: "Password_2",
            control: control,
            render: ({
              field,
              fieldState: {
                error
              }
            }) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
              className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_content),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
                className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_label),
                children: "Repet Password"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Input_Input__WEBPACK_IMPORTED_MODULE_5__/* .Input */ .I, _objectSpread({
                type: "text",
                showPass: true
              }, field)), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("p", {
                className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().error),
                children: error === null || error === void 0 ? void 0 : error.message
              })]
            })
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
          className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().dialog_content_btn),
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
            className: (_SignUp_module_css__WEBPACK_IMPORTED_MODULE_9___default().btn),
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_Button_Button__WEBPACK_IMPORTED_MODULE_4__/* .ButtonComp */ .C, {
              title: "Sign Up",
              big: true,
              type: true
            })
          })
        })]
      })]
    })
  });
};
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8104:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": () => (/* binding */ Title)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Title_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7067);
/* harmony import */ var _Title_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_Title_module_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);




const Title = ({
  title,
  title_2,
  nogradiental,
  conected,
  full
}) => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
    className: (_Title_module_css__WEBPACK_IMPORTED_MODULE_2___default().main_title),
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
      className: conected ? (_Title_module_css__WEBPACK_IMPORTED_MODULE_2___default().titlescon) : (_Title_module_css__WEBPACK_IMPORTED_MODULE_2___default().titles),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("p", {
        className: nogradiental ? (_Title_module_css__WEBPACK_IMPORTED_MODULE_2___default().title_) : (_Title_module_css__WEBPACK_IMPORTED_MODULE_2___default().title),
        children: title
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("p", {
        className: (_Title_module_css__WEBPACK_IMPORTED_MODULE_2___default().title_),
        children: title_2
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
      className: full ? (_Title_module_css__WEBPACK_IMPORTED_MODULE_2___default().row_full) : (_Title_module_css__WEBPACK_IMPORTED_MODULE_2___default().row)
    })]
  });
};

/***/ }),

/***/ 2804:
/***/ ((module) => {

// Exports
module.exports = {
	"btn_see_more": "Button_btn_see_more__44ab_",
	"btn_see_more_big": "Button_btn_see_more_big__OHnWu",
	"btn_see_more_2": "Button_btn_see_more_2__D_V_t",
	"btn_title": "Button_btn_title__W5YKe"
};


/***/ }),

/***/ 8604:
/***/ ((module) => {

// Exports
module.exports = {
	"btn_see_more": "SmallButton_btn_see_more__Imlra",
	"btn_see_more_2": "SmallButton_btn_see_more_2__GQYAR",
	"btn_title": "SmallButton_btn_title__woX3n"
};


/***/ }),

/***/ 8253:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "Footer_footer__1IwEk",
	"footer_content": "Footer_footer_content__xPnel",
	"keyNation": "Footer_keyNation__H2w6r",
	"keyNation_title": "Footer_keyNation_title__zjnwZ",
	"gradient": "Footer_gradient__kPvVK",
	"keyNation_subTitle": "Footer_keyNation_subTitle___8fLg",
	"left_block": "Footer_left_block__oc7vP",
	"officess": "Footer_officess__EiWQB",
	"prague_title": "Footer_prague_title__Jk2jw",
	"prague_titles": "Footer_prague_titles__Q_NNO",
	"subTitle": "Footer_subTitle__cWBHc",
	"prague_phone": "Footer_prague_phone__qTqUv",
	"strong": "Footer_strong__PjzY3",
	"us_office": "Footer_us_office__DcbRR",
	"row": "Footer_row__Iq0h_",
	"row_title": "Footer_row_title__sOo9D"
};


/***/ }),

/***/ 60:
/***/ ((module) => {

// Exports
module.exports = {
	"header": "Header_header__VVDoh",
	"header_logo": "Header_header_logo__Z30M5",
	"header_nav_login": "Header_header_nav_login___0XGP",
	"shopingCart": "Header_shopingCart__PkQZt",
	"header_login_reg": "Header_header_login_reg__Nkfry",
	"login_btn": "Header_login_btn__pbEk6",
	"reg_btn": "Header_reg_btn__7d9_g",
	"dialog_head": "Header_dialog_head__Vg_9D",
	"dialog_close": "Header_dialog_close__c56zZ",
	"dialog_title": "Header_dialog_title__X2cG5",
	"dialog_content_pass": "Header_dialog_content_pass__IcH34",
	"dialog_label": "Header_dialog_label__3HU54",
	"remember": "Header_remember__vfHbE",
	"remember_label": "Header_remember_label__5Cu3H",
	"dialog_content_btn": "Header_dialog_content_btn__o9iZH",
	"btn": "Header_btn__cSPEr",
	"forget_title": "Header_forget_title__Hzjk9",
	"dialog_filds": "Header_dialog_filds__bf5_b",
	"error": "Header_error__Bbyim"
};


/***/ }),

/***/ 3787:
/***/ ((module) => {

// Exports
module.exports = {
	"HeaderNavbar": "HeaderNavbar_HeaderNavbar__qYV86",
	"nav_items": "HeaderNavbar_nav_items__DbQam",
	"nav_item": "HeaderNavbar_nav_item__8eU_F",
	"menu_item": "HeaderNavbar_menu_item__jvIfq",
	"dropdown_icon_block": "HeaderNavbar_dropdown_icon_block__utwP3"
};


/***/ }),

/***/ 398:
/***/ ((module) => {

// Exports
module.exports = {
	"dropdown_head": "DropdownMenu_dropdown_head__bYgkd",
	"menu_item": "DropdownMenu_menu_item__cub3v",
	"dropdown_icon_block": "DropdownMenu_dropdown_icon_block__jDYiF",
	"dropedMenu": "DropdownMenu_dropedMenu__dhMi_",
	"dropdown_": "DropdownMenu_dropdown___9tztD",
	"dropedMenu_item": "DropdownMenu_dropedMenu_item__IMBiv",
	"dropedMenu_item_title": "DropdownMenu_dropedMenu_item_title__RVMSM"
};


/***/ }),

/***/ 6015:
/***/ ((module) => {

// Exports
module.exports = {
	"input": "Input_input__fo8G3",
	"input_block": "Input_input_block__5pkPU",
	"input_block_2": "Input_input_block_2__M0vq7",
	"input_pass": "Input_input_pass__kym8r",
	"showPass_icon": "Input_showPass_icon__1eAek"
};


/***/ }),

/***/ 6107:
/***/ ((module) => {

// Exports
module.exports = {
	"dialog_head": "ForgotPass_dialog_head__jlhvF",
	"dialog_back": "ForgotPass_dialog_back__eO_Eq",
	"dialog_close": "ForgotPass_dialog_close__eQ5ep",
	"dialog_back_title": "ForgotPass_dialog_back_title__kQWZY",
	"dialog_head_subTitle_block": "ForgotPass_dialog_head_subTitle_block__ZdS4w",
	"dialog_head_subTitle": "ForgotPass_dialog_head_subTitle__tD2V3",
	"dialog_label": "ForgotPass_dialog_label__ZixbN",
	"dialog_content_btn": "ForgotPass_dialog_content_btn__ZuZrW",
	"btn": "ForgotPass_btn__Bkly9",
	"error": "ForgotPass_error__ef9QZ"
};


/***/ }),

/***/ 18:
/***/ ((module) => {

// Exports
module.exports = {
	"dialog_head": "Login_dialog_head__N9xvi",
	"dialog_close": "Login_dialog_close__oppbU",
	"dialog_title": "Login_dialog_title__t6a61",
	"dialog_content_pass": "Login_dialog_content_pass__u8KUS",
	"dialog_label": "Login_dialog_label__vPhhL",
	"remember": "Login_remember__cC8YY",
	"remember_label": "Login_remember_label__MHPbo",
	"dialog_content_btn": "Login_dialog_content_btn__YWLoQ",
	"btn": "Login_btn__AnTvg",
	"forget_title": "Login_forget_title__LDWJf",
	"dialog_filds": "Login_dialog_filds__nKxnJ",
	"error": "Login_error__DwaXo"
};


/***/ }),

/***/ 9240:
/***/ ((module) => {

// Exports
module.exports = {
	"dialog_head": "SignUp_dialog_head__ee3G3",
	"dialog_close": "SignUp_dialog_close__NjvP9",
	"dialog_title": "SignUp_dialog_title__OHoON",
	"dialog_content_pass": "SignUp_dialog_content_pass__5QY2_",
	"dialog_label": "SignUp_dialog_label___EoAG",
	"remember": "SignUp_remember__Dsc0x",
	"remember_label": "SignUp_remember_label__rM_EL",
	"dialog_content_btn": "SignUp_dialog_content_btn__6xXEV",
	"btn": "SignUp_btn__9iJTy",
	"forget_title": "SignUp_forget_title__67lOD",
	"dialog_filds": "SignUp_dialog_filds__u2DPW",
	"error": "SignUp_error__x6yzT"
};


/***/ }),

/***/ 7067:
/***/ ((module) => {

// Exports
module.exports = {
	"main_title": "Title_main_title__qiM61",
	"titles": "Title_titles__NGvxQ",
	"titlescon": "Title_titlescon__szjzG",
	"title_": "Title_title___fCy3c",
	"title": "Title_title__KyDY2",
	"row": "Title_row__A6a8x",
	"row_full": "Title_row_full__k2s8y"
};


/***/ })

};
;